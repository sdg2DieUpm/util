extern int value;
void func(void) {
    value += 2;
}
