void dummy(void) {
}
